*** Settings ***
Documentation    suite de login no sistema ssw
Library          Browser

*** Test Cases ***
Realizar Login No SSW
    New Browser    browser=chromium    headless=False
    New Page    https://sistema.ssw.inf.br/bin/ssw0422

    Fill Text    id=1    Bmk
    Fill Text    id=2    55132128890
    Fill Text    id=3    gustavo
    Fill Text    id=4    418157

    Click      id=5
    Take Screenshot
    
Acessar o menu principal do SSW

    Fill Text    id=4   cadastro de veiculo
    Sleep     5