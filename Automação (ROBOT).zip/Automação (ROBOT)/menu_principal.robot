*** Settings ***
Documentation        suite de menu principal do sistema ssw
Library    Browser

*** Test Cases ***

