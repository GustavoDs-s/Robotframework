*** Settings ***

Documentation        Teste em Robot Framework

*** Test Cases ***
Deve mostrar uma mensagem de boas vindas 
    Log To Console    hello Robot
